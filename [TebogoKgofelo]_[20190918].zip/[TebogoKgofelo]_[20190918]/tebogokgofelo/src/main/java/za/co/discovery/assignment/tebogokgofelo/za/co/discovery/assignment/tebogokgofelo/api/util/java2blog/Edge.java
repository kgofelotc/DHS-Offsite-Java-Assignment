package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.util.java2blog;

public class Edge {

	private Vertex startVertex;
	private Vertex targetVertex;
	private double distance;
	
	public Edge(Vertex startVertex, Vertex targetVertex,double distance) {
		this.startVertex = startVertex;
		this.targetVertex = targetVertex;
		this.distance = distance;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public Vertex getStartVertex() {
		return startVertex;
	}
 
	public void setStartVertex(Vertex startVertex) {
		this.startVertex = startVertex;
	}
 
	public Vertex getTargetVertex() {
		return targetVertex;
	}
 
	public void setTargetVertex(Vertex targetVertex) {
		this.targetVertex = targetVertex;
	}
}
