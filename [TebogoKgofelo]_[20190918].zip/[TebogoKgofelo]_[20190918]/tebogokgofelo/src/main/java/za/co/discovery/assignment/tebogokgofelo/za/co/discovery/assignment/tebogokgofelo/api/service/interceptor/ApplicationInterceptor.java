package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.service.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

/**
 * Creating interceptors, so that we can have a visibility of all activities happening in our application
 */

@Component
public class ApplicationInterceptor implements HandlerInterceptor {
    Logger logger = LoggerFactory.getLogger("ApplicationInterceptor");
    @Override
    public boolean preHandle
            (HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {

        logger.info("Pre Handle method is Calling request action [" + request.getMethod()  + "] , request service name [" + request.getServletPath()  + "] ,response status [" + response.getStatus() + "]" );
        return true;
    }
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response,
                           Object handler, ModelAndView modelAndView) throws Exception {

        logger.info("Post Handle method is Calling request action [" + request.getMethod()  + "] , request service name [" + request.getServletPath()  + "] ,response status [" + response.getStatus() + "]" );
    }
    @Override
    public void afterCompletion
            (HttpServletRequest request, HttpServletResponse response, Object
                    handler, Exception exception) throws Exception {

        logger.info("Request and Response is completed request action [" + request.getMethod()  + "] , request service name [" + request.getServletPath()  + "] ,response status [" + response.getStatus() + "]" );
    }
}