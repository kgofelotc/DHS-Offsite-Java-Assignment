package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao;

import org.springframework.data.repository.CrudRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetDestination;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetOrigin;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.Route;

public interface RouteRepository extends CrudRepository<Route,Integer> {

    Route findByOriginAndDestination(PlanetOrigin planetOrigin, PlanetDestination planetDestination);
}

