package za.co.discovery.assignment.tebogokgofelo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TebogokgofeloApplication {

	public static void main(String[] args) {
		SpringApplication.run(TebogokgofeloApplication.class, args);
	}

}
