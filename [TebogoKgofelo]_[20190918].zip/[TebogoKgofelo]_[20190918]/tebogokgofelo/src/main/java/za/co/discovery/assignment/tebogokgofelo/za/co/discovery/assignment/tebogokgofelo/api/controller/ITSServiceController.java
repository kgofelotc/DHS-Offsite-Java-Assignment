package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.PlanetDestinationRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.PlanetOriginRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.RouteRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dto.DijkstraDto;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dto.RouteDto;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetDestination;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetOrigin;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.Route;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.util.java2blog.AlgorithmProcessor;

import java.util.ArrayList;
import java.util.List;

@RestController
public class ITSServiceController {

    @Autowired
    private AlgorithmProcessor algorithmProcessor;
    @Autowired
    private PlanetOriginRepository planetOriginRepository;
    @Autowired
    private PlanetDestinationRepository planetDestinationRepository;
    @Autowired
    private RouteRepository routeRepository;

    @GetMapping("/getShortestPathServiceByNames/{paramOrigin}/{paramDestination}")
    public String getShortestPathServiceByNames(@PathVariable String paramOrigin, @PathVariable String paramDestination){

        PlanetOrigin origin = planetOriginRepository.findByName(paramOrigin);
        PlanetDestination destination = planetDestinationRepository.findByName(paramDestination);
        List<PlanetOrigin> planetList = (List<PlanetOrigin>) planetOriginRepository.findAll();
        List<Route> routeList = (List<Route>) routeRepository.findAll();
        List<Route> routeListParam = new ArrayList<>();
        for (Route r : routeList) {
            if (r.getOrigin() == null || r.getDestination() == null) {
            } else {
                routeListParam.add(r);
            }
        }

        DijkstraDto dijkstraDto = algorithmProcessor.processShortestPath(origin, destination, planetList, routeListParam);

        return dijkstraDto.toString();
    }

    @GetMapping("/getShortestPathServiceByNodes/{paramOrigin}/{paramDestination}")
    public String getShortestPathServiceByNodes(@PathVariable String paramOrigin, @PathVariable String paramDestination){

        PlanetOrigin origin = planetOriginRepository.findByNode(paramOrigin);
        PlanetDestination destination = planetDestinationRepository.findByNode(paramDestination);
        List<PlanetOrigin> planetList = (List<PlanetOrigin>) planetOriginRepository.findAll();
        List<Route> routeList = (List<Route>) routeRepository.findAll();
        List<Route> routeListParam = new ArrayList<>();
        for (Route r : routeList) {
            if (r.getOrigin() == null || r.getDestination() == null) {
            } else {
                routeListParam.add(r);
            }
        }

        DijkstraDto dijkstraDto = algorithmProcessor.processShortestPath(origin, destination, planetList, routeListParam);

        return dijkstraDto.toString();
    }
}


