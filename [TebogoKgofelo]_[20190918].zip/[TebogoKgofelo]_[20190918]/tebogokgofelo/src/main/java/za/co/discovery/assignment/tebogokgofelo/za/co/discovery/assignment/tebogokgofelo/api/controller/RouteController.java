package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.PlanetDestinationRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.PlanetOriginRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.RouteRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dto.RouteDto;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetDestination;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetOrigin;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.Route;

import java.util.ArrayList;
import java.util.List;

@RestController
public class RouteController {

    @Autowired
    private RouteRepository routeRepository ;
    @Autowired
    private PlanetOriginRepository planetOriginRepository;
    @Autowired
    private PlanetDestinationRepository planetDestinationRepository;

    @PostMapping("/createRoutesByNodes")
    public String createRoutesByNodes(@RequestBody List<Route> routes){
        routeRepository.saveAll(routes);
        return routes.size() + " record saved...";
    }

    @GetMapping("/getAllRoutes")
    public List<Route> getAllRoutes(){
        return (List<Route>) routeRepository.findAll();
    }



}
