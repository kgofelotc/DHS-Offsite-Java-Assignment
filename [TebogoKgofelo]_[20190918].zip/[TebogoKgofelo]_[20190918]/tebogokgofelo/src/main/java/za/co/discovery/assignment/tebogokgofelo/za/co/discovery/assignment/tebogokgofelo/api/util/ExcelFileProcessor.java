package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.util;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.ResourceUtils;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dto.RouteDto;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetDestination;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetOrigin;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.Route;

@Configuration
public class ExcelFileProcessor {

    Logger logger = LoggerFactory.getLogger(ExcelFileProcessor.class.getName());

    public static final String XLSX_FILE = "Interstellar Transport System Data.xlsx";

    @Bean
    public List<PlanetDestination> getPlanetDestinationList() {

        logger.info("Loading Planet Destinations data started...");

        List<PlanetDestination> planetDestinations = new ArrayList<>();

        try {
            File file = ResourceUtils.getFile("classpath:" + XLSX_FILE);
            FileInputStream excelFile = new FileInputStream(file);
            Workbook workbook = new XSSFWorkbook(excelFile);
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            PlanetDestination planetDestination;
            while (rowIterator.hasNext()) {
                Row currentRow = rowIterator.next();
                if (currentRow.getRowNum() == 0) {
                    continue;
                }
                planetDestination = new PlanetDestination();
                String node = currentRow.getCell(0).toString();
                if (node.contains("\'")) {
                    planetDestination.setNode(node);
                } else {
                    planetDestination.setNode(node);
                }
                planetDestination.setName(currentRow.getCell(1).toString());
                planetDestinations.add(planetDestination);
            }
        } catch (FileNotFoundException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
        logger.info("Loading Planet Destinations data completed...");
        return planetDestinations;
    }

    @Bean
    public List<PlanetOrigin> getPlanetOrginList() {
        logger.info("Loading Planet Origin data started...");
        List<PlanetOrigin> planetOrigins = new ArrayList<>();

        try {
            File file = ResourceUtils.getFile("classpath:" + XLSX_FILE);
            FileInputStream excelFile = new FileInputStream(file);
            Workbook workbook = new XSSFWorkbook(excelFile);
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            PlanetOrigin planetOrigin;
            while (rowIterator.hasNext()) {
                Row currentRow = rowIterator.next();
                if (currentRow.getRowNum() == 0) {
                    continue;
                }
                planetOrigin = new PlanetOrigin();
                String node = currentRow.getCell(0).toString();
                if (node.contains("\'")) {
                    planetOrigin.setNode(node);
                } else {
                    planetOrigin.setNode(node);
                }
                planetOrigin.setName(currentRow.getCell(1).toString());
                planetOrigins.add(planetOrigin);
            }
        } catch (FileNotFoundException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
        logger.info("Loading Planet Origin data completed...");
        return planetOrigins;
    }

    @Bean
    public List<RouteDto> getRouteList() {

        logger.info("Loading Planet Routes data started...");

        List<RouteDto> routes = new ArrayList<>();

        try {
            File file = ResourceUtils.getFile("classpath:" + XLSX_FILE);
            FileInputStream excelFile = new FileInputStream(file);
            Workbook workbook = new XSSFWorkbook(excelFile);
            Sheet sheet = workbook.getSheetAt(1);
            Iterator<Row> rowIterator = sheet.iterator();
            RouteDto route;
            while (rowIterator.hasNext()) {
                Row currentRow = rowIterator.next();
                if (currentRow.getRowNum() == 0) {
                    continue;
                }
                route = new RouteDto();
                route.setOrigin(currentRow.getCell(1).toString());
                route.setDestination(currentRow.getCell(2).toString());
                route.setDistance(currentRow.getCell(3).getNumericCellValue());
                routes.add(route);
            }
        } catch (FileNotFoundException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
        logger.info("Loading Planet RouteDtos data completed...");
        logger.info("Number of Routes found : " + routes.size());
        return routes;

    }
}
