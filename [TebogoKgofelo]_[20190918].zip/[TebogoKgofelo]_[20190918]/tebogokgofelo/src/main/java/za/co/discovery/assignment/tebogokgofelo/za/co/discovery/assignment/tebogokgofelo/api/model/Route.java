package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Route {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "route_id")
    private int id;
    @OneToOne
    @JoinColumn(name = "origin_id")
    private PlanetOrigin origin;
    @OneToOne
    @JoinColumn(name = "destination_id")
    private PlanetDestination destination;
    private Double distance;
    private Double traffic;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public PlanetOrigin getOrigin() {
        return origin;
    }

    public void setOrigin(PlanetOrigin origin) {
        this.origin = origin;
    }

    public PlanetDestination getDestination() {
        return destination;
    }

    public void setDestination(PlanetDestination destination) {
        this.destination = destination;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public Double getTraffic() {
        return traffic;
    }

    public void setTraffic(Double traffic) {
        this.traffic = traffic;
    }

    @Override
    public String toString() {
        return "Route{" +
                "id=" + id +
                ", origin=" + origin +
                ", destination=" + destination +
                ", distance='" + distance + '\'' +
                ", traffic='" + traffic + '\'' +
                '}';
    }
}
