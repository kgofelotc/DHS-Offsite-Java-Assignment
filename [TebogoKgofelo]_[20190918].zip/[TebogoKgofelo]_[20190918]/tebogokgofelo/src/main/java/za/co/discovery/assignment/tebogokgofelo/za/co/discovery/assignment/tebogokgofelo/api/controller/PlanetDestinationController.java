package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.PlanetDestinationRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetDestination;

import java.util.List;

@RestController
public class PlanetDestinationController {

    @Autowired
    private PlanetDestinationRepository planetDestinationRepository;

    @PostMapping("/createPlanetDestinations")
    public String createPlanetDestinations(@RequestBody List<PlanetDestination> planetDestinationList){
        planetDestinationRepository.saveAll(planetDestinationList);
        return planetDestinationList.size() + " record saved...";
    }

    @GetMapping("/getAllPlanetDestinations")
    public List<PlanetDestination> getAllPlanetDestinations(){
        return (List<PlanetDestination>) planetDestinationRepository.findAll();
    }

    @GetMapping("/getPlanetDestinationByName/{name}")
    public PlanetDestination getPlanetDestinationByName(@PathVariable String name){
        return planetDestinationRepository.findByName(name);
    }

    @GetMapping("/getPlanetDestinationByNode/{node}")
    public PlanetDestination getPlanetDestinationByNode(@PathVariable String node){
        return planetDestinationRepository.findByNode(node);
    }
}
