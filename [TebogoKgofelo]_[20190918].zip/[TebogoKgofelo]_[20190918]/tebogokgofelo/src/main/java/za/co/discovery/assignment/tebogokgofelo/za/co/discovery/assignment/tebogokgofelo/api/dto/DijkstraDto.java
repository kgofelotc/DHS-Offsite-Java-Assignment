package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dto;

import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.util.java2blog.Vertex;

import java.util.List;

public class DijkstraDto {

    private String origin;
    private String destination;
    private Double distance;
    private List<Vertex> path;

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public List<Vertex> getPath() {
        return path;
    }

    public void setPath(List<Vertex> path) {
        this.path = path;
    }

    @Override
    public String toString() {
        return "DijkstraDto{" +
                "origin='" + origin + '\'' +
                ", destination='" + destination + '\'' +
                ", distance=" + distance +
                ", path=" + path +
                '}';
    }
}

