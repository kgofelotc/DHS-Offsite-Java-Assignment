package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dto;

public class RouteDto {

    private int id;
    private String origin;
    private String destination;
    private Double distance;
    private Double traffic;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public Double getTraffic() {
        return traffic;
    }

    public void setTraffic(Double traffic) {
        this.traffic = traffic;
    }

    @Override
    public String toString() {
        return "Route{" +
                "id=" + id +
                ", origin=" + origin +
                ", destination=" + destination +
                ", distance='" + distance + '\'' +
                ", traffic='" + traffic + '\'' +
                '}';
    }
}
