package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.PlanetOriginRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetOrigin;

import java.util.List;

@RestController
public class PlanetOriginController {

    @Autowired
    private PlanetOriginRepository planetOriginRepository;

    @PostMapping("/createPlanetOrigins")
    public String createPlanetOrigins(@RequestBody List<PlanetOrigin> planetOriginList){
        planetOriginRepository.saveAll(planetOriginList);
        return planetOriginList.size() + " record saved...";
    }

    @GetMapping("/getAllPlanetOrigins")
    public List<PlanetOrigin> getAllPlanets(){
        return (List<PlanetOrigin>) planetOriginRepository.findAll();
    }

    @GetMapping("/getPlanetOriginByName/{name}")
    public PlanetOrigin findPlanetByName(@PathVariable String name){
        return planetOriginRepository.findByName(name);
    }

    @GetMapping("/getPlanetOriginByNode/{node}")
    public PlanetOrigin getPlanetOriginByNode(@PathVariable String node){
        return planetOriginRepository.findByNode(node);
    }
}
