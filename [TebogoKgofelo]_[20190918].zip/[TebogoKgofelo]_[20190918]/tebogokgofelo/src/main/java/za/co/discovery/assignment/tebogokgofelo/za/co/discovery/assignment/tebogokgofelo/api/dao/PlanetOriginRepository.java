package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao;

import org.springframework.data.repository.CrudRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetOrigin;

public interface PlanetOriginRepository extends CrudRepository<PlanetOrigin,Integer> {

    PlanetOrigin findByName(String name);
    PlanetOrigin findByNode(String node);
}
