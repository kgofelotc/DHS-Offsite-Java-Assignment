package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model;


import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        ObjectMapper mapper = new ObjectMapper();

        Route staff = getObjectData();

        try {


            // Java objects to JSON string - compact-print
            String jsonString = mapper.writeValueAsString(staff);

            System.out.println(jsonString);

            // Java objects to JSON string - pretty-print
            String jsonInString2 = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(staff);

            System.out.println(jsonInString2);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    // Get the data to be inserted into the object
    public static Route getObjectData() {

        PlanetOrigin origin = new PlanetOrigin();
        origin.setName("Earth");
        origin.setNode("A");
        PlanetDestination destination = new PlanetDestination();
        destination.setName("Moon");
        destination.setNode("B");

        List<Route> routeList = new ArrayList<>();
        Route route = new Route();
        route.setOrigin(origin);
        route.setDestination(destination);
        route.setDistance(0.44);
        routeList.add(route);

        // Return the object
        return route;
    }
}
