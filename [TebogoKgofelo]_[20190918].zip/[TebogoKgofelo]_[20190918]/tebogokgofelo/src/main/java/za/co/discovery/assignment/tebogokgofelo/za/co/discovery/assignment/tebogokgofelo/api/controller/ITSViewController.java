package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.PlanetDestinationRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.PlanetOriginRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.RouteRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dto.DijkstraDto;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dto.RouteDto;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetDestination;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetOrigin;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.Route;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.util.java2blog.AlgorithmProcessor;

import java.util.ArrayList;
import java.util.List;

@Controller
public class ITSViewController {

    Logger logger = LoggerFactory.getLogger(ITSViewController.class.getName());

    @Value("${welcome.message}")
    private String message;
    @Autowired
    private AlgorithmProcessor algorithmProcessor;
    @Autowired
    private PlanetOriginRepository planetOriginRepository;
    @Autowired
    private PlanetDestinationRepository planetDestinationRepository;
    @Autowired
    private RouteRepository routeRepository;

    @GetMapping("/")
    public String main(Model model) {
        //create a reservation object
        RouteDto routeDto = new RouteDto();
        //provide reservation object to the model
        model.addAttribute("routeDto", routeDto);
        model.addAttribute("message", message);
        List<PlanetOrigin> planetOriginList = (List<PlanetOrigin>) planetOriginRepository.findAll();
        model.addAttribute("planetOrigins", planetOriginList);
        return "index"; //view
    }

    @GetMapping("/hello")
    public String mainWithParam(@RequestParam(name = "name", required = false, defaultValue = "") String name, Model model) {
        model.addAttribute("message", name);
        return "welcome"; //view
    }

    @PostMapping("/getShortestPath")
    public String processForm(RouteDto routeDto, Model model) {
        logger.info("Origin : " + routeDto.getOrigin());
        logger.info("Destination : " + routeDto.getDestination());

        PlanetOrigin origin = planetOriginRepository.findByName(routeDto.getOrigin());
        PlanetDestination destination = planetDestinationRepository.findByName(routeDto.getDestination());
        List<PlanetOrigin> planetList = (List<PlanetOrigin>) planetOriginRepository.findAll();
        List<Route> routeList = (List<Route>) routeRepository.findAll();
        List<Route> routeListParam = new ArrayList<>();
        for (Route r : routeList) {
            //Remove routes without origin or destination
            if (r.getOrigin() == null || r.getDestination() == null) {
                logger.info("Remove : " + r);
            } else {
                routeListParam.add(r);
            }
        }
        DijkstraDto dijkstraDto = algorithmProcessor.processShortestPath(origin, destination, planetList, routeListParam);
        String processedResults = "Minimum distance from " + dijkstraDto.getOrigin()
                + " to " + dijkstraDto.getDestination()
                + " is " + String.format("%.2f", dijkstraDto.getDistance())
                + " and the shortest Path is " + dijkstraDto.getPath();
        model.addAttribute("results", processedResults);

        return "shortestPath";
    }

}