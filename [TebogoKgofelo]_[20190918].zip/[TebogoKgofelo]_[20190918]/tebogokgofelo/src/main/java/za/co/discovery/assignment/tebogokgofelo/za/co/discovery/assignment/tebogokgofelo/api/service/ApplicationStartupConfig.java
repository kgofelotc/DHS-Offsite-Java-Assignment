package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.PlanetDestinationRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.PlanetOriginRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao.RouteRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dto.RouteDto;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetDestination;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetOrigin;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.Route;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.util.ExcelFileProcessor;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.util.java2blog.AlgorithmProcessor;

import java.util.ArrayList;
import java.util.List;

/**
 * Spring Boot Application Startup Listener to load data from file to database
 */
@Component
public class ApplicationStartupConfig implements ApplicationListener<ApplicationReadyEvent> {

    Logger logger = LoggerFactory.getLogger(ApplicationStartupConfig.class.getName());

    @Autowired
    private PlanetOriginRepository planetOriginRepository;
    @Autowired
    private PlanetDestinationRepository planetDestinationRepository;
    @Autowired
    private RouteRepository routeRepository;
    @Autowired
    private ExcelFileProcessor excelFileProcessor;
    @Autowired
    private AlgorithmProcessor algorithmProcessor;

    /**
     * This event is executed as late as conceivably possible to indicate that
     * the application is ready to service requests.
     */
    @Override
    public void onApplicationEvent(final ApplicationReadyEvent event) {
        logger.info("Initializing application resources started...");

        List<PlanetDestination> planetDestinations = excelFileProcessor.getPlanetDestinationList();
        planetDestinationRepository.saveAll(planetDestinations);
        logger.info("Saved planetDestinations " + planetDestinations.size());

        List<PlanetOrigin> planetOrigins = excelFileProcessor.getPlanetOrginList();
        planetOriginRepository.saveAll(planetOrigins);
        logger.info("Saved planetOrigins " + planetOrigins.size());

        List<RouteDto> routeDtos = excelFileProcessor.getRouteList();
        List<Route> routes = new ArrayList<>();
        for (RouteDto routeDto : routeDtos) {
            PlanetOrigin planetOrigin = planetOriginRepository.findByNode(routeDto.getOrigin());
            PlanetDestination planetDestination = planetDestinationRepository.findByNode(routeDto.getDestination());
            Route route = new Route();
            route.setOrigin(planetOrigin);
            route.setDestination(planetDestination);
            route.setDistance(routeDto.getDistance());
            routes.add(route);
        }
        routeRepository.saveAll(routes);
        logger.info("Saved routes " + routes.size());

        logger.info("Initializing application resources completed...");
        PlanetOrigin origin = planetOriginRepository.findByName("Earth");
        PlanetDestination destination = planetDestinationRepository.findByName("Moon");
        List<PlanetOrigin> planetList = (List<PlanetOrigin>) planetOriginRepository.findAll();
        List<Route> routeList = (List<Route>) routeRepository.findAll();
        List<Route> routeListParam = new ArrayList<>();
        for (Route r : routeList) {
            //Remove routes without origin or destination (Doing this for the sake of my sanity)
            if (r.getOrigin() == null || r.getDestination() == null) {
                logger.info("Remove : " + r);
            } else {
                routeListParam.add(r);
            }
        }
        algorithmProcessor.processShortestPath(origin, destination, planetList, routeListParam);
    }

}
