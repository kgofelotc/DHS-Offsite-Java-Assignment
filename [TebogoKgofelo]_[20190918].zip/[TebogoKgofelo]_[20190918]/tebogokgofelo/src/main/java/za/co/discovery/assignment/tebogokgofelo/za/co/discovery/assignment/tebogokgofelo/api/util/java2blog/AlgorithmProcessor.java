package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.util.java2blog;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dto.DijkstraDto;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetDestination;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetOrigin;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.Route;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class AlgorithmProcessor {

    Logger logger = LoggerFactory.getLogger(AlgorithmProcessor.class.getName());

    public DijkstraDto processShortestPath(PlanetOrigin planetOrigin, PlanetDestination planetDestination, List<PlanetOrigin> planetList, List<Route> routeList) {

        DijkstraShortestPath dijkstra = new DijkstraShortestPath();

        List<Vertex> vertexList = new ArrayList<>();
        Vertex vertexOrigin = null;
        Vertex vertexDestination = null;
        for (PlanetOrigin origin : planetList) {
            Vertex vertex = new Vertex(origin.getNode());
            if(planetOrigin.getNode().toString().equals(origin.getNode())){
                vertexOrigin = vertex;
            }
            if(planetDestination.getNode().toString().equals(origin.getNode())){
                vertexDestination = vertex;
            }
            vertexList.add(vertex);
        }

        for (Vertex vertex: vertexList) {
            for (Route route : routeList) {
                String v = vertex.getName();
                String n = route.getOrigin().getNode();
                    if(v.equals(n)){
                       Vertex vertex1 = null;
                        for(Vertex vertex2 : vertexList){
                            if(vertex2.getName().equals(route.getDestination().getNode())){
                                vertex1 = vertex2;
                            }
                        }
                        vertex.addNeighbour(new Edge(vertex, vertex1, route.getDistance()));
                    }
            }
        }

        dijkstra.computeShortestPaths(vertexOrigin);

        DijkstraDto dijkstraDto = new DijkstraDto();
        dijkstraDto.setOrigin(planetOrigin.getNode() + "-" + planetOrigin.getName());
        dijkstraDto.setDestination(planetDestination.getNode() + "-" + planetDestination.getName());
        dijkstraDto.setDistance(vertexDestination.getDistance());
        dijkstraDto.setPath(dijkstra.getShortestPathTo(vertexDestination));

        logger.info(dijkstraDto.toString());

        return dijkstraDto;
    }
}
