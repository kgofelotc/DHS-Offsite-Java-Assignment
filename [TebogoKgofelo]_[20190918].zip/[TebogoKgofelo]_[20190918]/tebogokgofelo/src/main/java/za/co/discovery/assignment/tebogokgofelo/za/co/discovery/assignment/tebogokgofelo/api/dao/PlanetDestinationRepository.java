package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dao;

import org.springframework.data.repository.CrudRepository;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetDestination;

public interface PlanetDestinationRepository extends CrudRepository<PlanetDestination,Integer> {

    PlanetDestination findByName(String name);
    PlanetDestination findByNode(String node);
}
