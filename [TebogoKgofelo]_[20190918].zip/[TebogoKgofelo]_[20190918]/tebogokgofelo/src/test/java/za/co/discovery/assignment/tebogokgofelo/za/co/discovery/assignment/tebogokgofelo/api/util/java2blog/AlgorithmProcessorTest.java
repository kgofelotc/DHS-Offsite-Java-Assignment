package za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.util.java2blog;

import org.junit.Before;
import org.junit.Test;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.dto.DijkstraDto;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetDestination;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.PlanetOrigin;
import za.co.discovery.assignment.tebogokgofelo.za.co.discovery.assignment.tebogokgofelo.api.model.Route;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

/**
 * We create a test for our important util, so that if anything changes, we are able to detect the changes
 * This test covers at least 66% of our method coverage and 86% lines of code is covered
 */

public class AlgorithmProcessorTest {

    private AlgorithmProcessor processor;
    private DijkstraDto dijkstraDtoActual;

    PlanetOrigin origin;
    PlanetDestination destination;
    List<PlanetOrigin> planetList;
    List<Route> routeList;

    @Before
    public void setUp() {
        processor = new AlgorithmProcessor();

        dijkstraDtoActual = new DijkstraDto();
        dijkstraDtoActual.setOrigin("A-Earth");
        dijkstraDtoActual.setDestination("B-Moon");
        dijkstraDtoActual.setDistance(0.44);

        origin = new PlanetOrigin();
        origin.setName("Earth");
        origin.setNode("A");
        destination = new PlanetDestination();
        destination.setName("Moon");
        destination.setNode("B");

        planetList = new ArrayList<>();
        planetList.add(origin);
        PlanetOrigin planetOriginC = new PlanetOrigin();
        planetOriginC.setName("Pluto");
        planetOriginC.setNode("C");
        planetList.add(planetOriginC);
        PlanetOrigin planetOriginB = new PlanetOrigin();
        planetOriginB.setName("Moon");
        planetOriginB.setNode("B");
        planetList.add(planetOriginB);

        routeList = new ArrayList<>();
        Route route = new Route();
        route.setOrigin(origin);
        route.setDestination(destination);
        route.setDistance(0.44);
        routeList.add(route);
    }

    @Test
    public void processShortestPath() {

        DijkstraDto dijkstraDto = processor.processShortestPath(origin, destination, planetList, routeList);

        assertEquals(dijkstraDto.getOrigin(), dijkstraDtoActual.getOrigin());
        assertEquals(dijkstraDto.getDestination(), dijkstraDtoActual.getDestination());
        assertEquals(dijkstraDto.getDistance(), dijkstraDtoActual.getDistance());

    }
}